"""
Quasi-static time-series (QSTS) simulation: 24 independent AC power flows,
one per hour, solved with pandapower's Newton-Raphson solver.

"Quasi-static" = every hour is a steady-state snapshot; dynamics (inverter
control, transients, EV arrival randomness) are not modelled.
"""
from dataclasses import dataclass
from typing import Dict

import numpy as np
import pandas as pd
import pandapower as pp

from . import config as C
from .bess import schedule_bess
from .network import bus_idx, build_network
from .profiles import ev_profile, load_profile, pv_profile, validate_profile

# Cumulative scenarios: each one adds a layer to the previous one.
SCENARIOS: Dict[str, Dict[str, bool]] = {
    "S0_base":        dict(pv=False, ev=False, bess=False),
    "S1_pv":          dict(pv=True,  ev=False, bess=False),
    "S2_pv_ev":       dict(pv=True,  ev=True,  bess=False),
    "S3_pv_ev_bess":  dict(pv=True,  ev=True,  bess=True),
}
LABELS = {
    "S0_base": "S0 Base",
    "S1_pv": "S1 + PV",
    "S2_pv_ev": "S2 + PV + EV",
    "S3_pv_ev_bess": "S3 + PV + EV + BESS",
}


class PowerFlowError(RuntimeError):
    pass


@dataclass
class TimeSeriesResult:
    name: str
    vm: pd.DataFrame            # hour x bus (1..33) voltage magnitude [pu]
    line_loading: pd.DataFrame  # hour x line (1..32) [% of assumed ampacity]
    losses_kw: np.ndarray       # network (I^2 R) losses per hour [kW]
    p_import_mw: np.ndarray     # active power drawn from the substation [MW]
    q_import_mvar: np.ndarray
    load_mw: np.ndarray         # original feeder demand
    ev_mw: np.ndarray
    pv_mw: np.ndarray
    bess_mw: np.ndarray         # + = charging
    bess_soc: np.ndarray
    bess_conv_loss_kwh: float


def simulate(name: str, study: C.Study) -> TimeSeriesResult:
    flags = SCENARIOS[name]
    lp, pvp, evp = load_profile(), pv_profile(study.pv_peak_cf), ev_profile()
    for n, a in (("load", lp), ("pv", pvp), ("ev", evp)):
        validate_profile(n, a)

    net = build_network()
    base_idx = net.load.index.to_numpy()
    p0, q0 = net.load.p_mw.to_numpy().copy(), net.load.q_mvar.to_numpy().copy()

    pv_idx, ev_idx, st_idx = [], [], None
    pv_kw_site = study.pv_kwp_per_site * study.pv_scale
    if flags["pv"]:
        for b in study.pv_buses:
            # q = 0: unity power factor inverter (no Volt-VAR control, see limitations)
            pv_idx.append(pp.create_sgen(net, bus=bus_idx(b), p_mw=0.0, q_mvar=0.0, name=f"PV {b}"))
    if flags["ev"]:
        for b in study.ev_buses:
            ev_idx.append(pp.create_load(net, bus=bus_idx(b), p_mw=0.0, q_mvar=0.0, name=f"EV hub {b}"))
    sched = None
    if flags["bess"]:
        sched = schedule_bess(study)
        st_idx = pp.create_storage(net, bus=bus_idx(study.bess_bus), p_mw=0.0,
                                   max_e_mwh=study.bess_energy_mwh, name="BESS")

    # Daily AC energy of ONE EV hub [MWh] and the resulting hourly power [MW]
    ev_hub_mwh = study.ev_vehicles_per_hub * study.ev_kwh_per_vehicle_day * study.ev_scale / 1000.0
    ev_hub_mw = ev_hub_mwh * evp                       # dt = 1 h, so MWh/h = MW
    tan_phi = np.tan(np.arccos(study.ev_pf))

    n = 24
    vm = np.zeros((n, 33)); ll = np.zeros((n, 32)); loss = np.zeros(n)
    pimp = np.zeros(n); qimp = np.zeros(n)
    pv_tot = np.zeros(n); ev_tot = np.zeros(n); bess_tot = np.zeros(n)

    for h in range(n):
        net.load.loc[base_idx, "p_mw"] = p0 * lp[h]
        net.load.loc[base_idx, "q_mvar"] = q0 * lp[h]
        for i in pv_idx:
            net.sgen.at[i, "p_mw"] = pv_kw_site / 1000.0 * pvp[h]
        for i in ev_idx:
            net.load.at[i, "p_mw"] = ev_hub_mw[h]
            net.load.at[i, "q_mvar"] = ev_hub_mw[h] * tan_phi
        if st_idx is not None:
            net.storage.at[st_idx, "p_mw"] = sched.p_mw[h]
        try:
            pp.runpp(net, numba=False)
        except pp.LoadflowNotConverged as exc:
            raise PowerFlowError(f"{name}: power flow did not converge at hour {h}") from exc

        vm[h] = net.res_bus.vm_pu.to_numpy()
        ll[h] = net.res_line.loading_percent.to_numpy()
        loss[h] = net.res_line.pl_mw.sum() * 1000.0
        pimp[h] = net.res_ext_grid.p_mw.iloc[0]
        qimp[h] = net.res_ext_grid.q_mvar.iloc[0]
        pv_tot[h] = sum(net.sgen.at[i, "p_mw"] for i in pv_idx)
        ev_tot[h] = sum(net.load.at[i, "p_mw"] for i in ev_idx)
        bess_tot[h] = sched.p_mw[h] if sched is not None else 0.0

    return TimeSeriesResult(
        name=name,
        vm=pd.DataFrame(vm, columns=range(1, 34)),
        line_loading=pd.DataFrame(ll, columns=range(1, 33)),
        losses_kw=loss, p_import_mw=pimp, q_import_mvar=qimp,
        load_mw=p0.sum() * lp, ev_mw=ev_tot, pv_mw=pv_tot, bess_mw=bess_tot,
        bess_soc=sched.soc if sched is not None else np.zeros(n),
        bess_conv_loss_kwh=(sched.conversion_loss_mwh * 1000.0) if sched is not None else 0.0,
    )


def run_all(study: C.Study) -> Dict[str, TimeSeriesResult]:
    return {name: simulate(name, study) for name in SCENARIOS}
