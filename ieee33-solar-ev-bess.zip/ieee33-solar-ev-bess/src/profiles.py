"""
Synthetic 24-hour profiles (hour h covers h:00 -> h+1:00).

ALL PROFILES HERE ARE ILLUSTRATIVE / SYNTHETIC, not measured data. They are
shaped after typical textbook curves so the study is reproducible. Replace
them with utility or smart-meter data for a real study.
"""
import numpy as np

HOURS = np.arange(24)


def load_profile() -> np.ndarray:
    """Feeder demand as a fraction of the tabulated peak (1.0 = Baran & Wu loads)."""
    p = np.array([0.62, 0.58, 0.55, 0.54, 0.55, 0.60, 0.68, 0.75, 0.78, 0.78, 0.80, 0.82,
                  0.82, 0.80, 0.80, 0.82, 0.86, 0.92, 0.97, 1.00, 1.00, 0.95, 0.80, 0.68])
    return p


def pv_profile(peak_cf: float = 0.85) -> np.ndarray:
    """
    Clear-day PV output as a fraction of installed kWp: a half-sine between
    06:00 and 18:00, evaluated at the middle of each hour, scaled by `peak_cf`.
    """
    t = HOURS + 0.5
    shape = np.where((t >= 6) & (t <= 18), np.sin(np.pi * (t - 6) / 12.0), 0.0)
    return peak_cf * shape


def ev_profile() -> np.ndarray:
    """Share of the daily EV charging energy drawn in each hour (sums to 1)."""
    w = np.array([0.04, 0.03, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02,
                  0.02, 0.02, 0.02, 0.03, 0.04, 0.06, 0.09, 0.12, 0.12, 0.10, 0.08, 0.06])
    return w / w.sum()


def validate_profile(name: str, arr: np.ndarray) -> None:
    if arr.shape != (24,):
        raise ValueError(f"Profile '{name}' must have 24 hourly values, got {arr.shape}")
    if np.any(arr < 0) or not np.all(np.isfinite(arr)):
        raise ValueError(f"Profile '{name}' contains negative or non-finite values")
