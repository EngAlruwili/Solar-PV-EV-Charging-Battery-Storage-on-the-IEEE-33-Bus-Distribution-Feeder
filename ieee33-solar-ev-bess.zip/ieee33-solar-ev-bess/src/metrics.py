"""
Key performance indicators (KPIs). All are computed from the power-flow results.

  V_min, V_max      : lowest / highest bus voltage magnitude over the day [pu]
  V_min evening     : lowest voltage between 18:00 and 22:00 (the feeder peak) [pu]
  Under/over-voltage: number of (bus, hour) pairs outside [0.95, 1.05] pu
                      (the slack bus is excluded because it is a fixed setpoint)
  Network losses    : E_loss = sum_h  sum_lines P_loss,l(h) * dt        [kWh]
  Loss share        : E_loss / E_import x 100                            [%]
  Max line loading  : max over lines and hours of  I / I_rated x 100     [%]
                      (I_rated is an ASSUMED ampacity, see network.py)
  Peak import       : max_h P_substation(h)                              [MW]
  System losses     : network losses + battery round-trip losses         [kWh]
"""
import numpy as np
import pandas as pd

from . import config as C
from .simulate import LABELS, TimeSeriesResult


def kpis(r: TimeSeriesResult) -> dict:
    v = r.vm.drop(columns=[1])                      # exclude slack bus
    v_arr = v.to_numpy()
    h_min, b_min = np.unravel_index(np.argmin(v_arr), v_arr.shape)
    h_max, b_max = np.unravel_index(np.argmax(v_arr), v_arr.shape)
    e_loss = float(r.losses_kw.sum())               # dt = 1 h
    e_import = float(r.p_import_mw.sum() * 1000.0)  # kWh (net, can be reduced by PV)
    under = int((v_arr < C.V_MIN_PU).sum())
    over = int((v_arr > C.V_MAX_PU).sum())
    ll = r.line_loading.to_numpy()
    return {
        "Scenario": LABELS[r.name],
        "V_min [pu]": round(float(v_arr.min()), 4),
        "V_min bus / hour": f"{v.columns[b_min]} / {h_min:02d}:00",
        "V_min evening 18-22h [pu]": round(float(v.loc[18:21].to_numpy().min()), 4),
        "V_max [pu]": round(float(v_arr.max()), 4),
        "V_max bus / hour": f"{v.columns[b_max]} / {h_max:02d}:00",
        "Undervoltage bus-hours (<0.95)": under,
        "Overvoltage bus-hours (>1.05)": over,
        "Network losses [kWh/day]": round(e_loss, 1),
        "Peak loss [kW]": round(float(r.losses_kw.max()), 1),
        "Loss share of import [%]": round(100.0 * e_loss / e_import, 2),
        "Battery conversion loss [kWh/day]": round(r.bess_conv_loss_kwh, 1),
        "System losses incl. battery [kWh/day]": round(e_loss + r.bess_conv_loss_kwh, 1),
        "Max line loading [% of assumed rating]": round(float(ll.max()), 1),
        "Line-hours above 100%": int((ll > 100.0).sum()),
        "Peak substation import [MW]": round(float(r.p_import_mw.max()), 3),
        "Energy imported [MWh/day]": round(e_import / 1000.0, 2),
    }


def kpi_table(results: dict) -> pd.DataFrame:
    return pd.DataFrame([kpis(r) for r in results.values()]).set_index("Scenario")


def energy_balance_error_mw(r: TimeSeriesResult) -> float:
    """
    P_import = P_load + P_EV + P_battery(charging +) - P_PV + P_loss   (every hour).
    Returns the maximum absolute violation [MW]; should be ~1e-9.
    """
    rhs = r.load_mw + r.ev_mw + r.bess_mw - r.pv_mw + r.losses_kw / 1000.0
    return float(np.max(np.abs(r.p_import_mw - rhs)))
