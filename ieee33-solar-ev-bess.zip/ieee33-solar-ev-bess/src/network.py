"""
IEEE 33-bus radial distribution feeder (Baran & Wu, 1989) built with pandapower.

Data source: M. E. Baran and F. F. Wu, "Network reconfiguration in distribution
systems for loss reduction and load balancing," IEEE Trans. Power Delivery,
vol. 4, no. 2, 1989. The five normally-open tie lines are NOT modelled, so the
network stays radial.

Units: R, X in ohm; loads in kW / kvar (converted to MW / Mvar for pandapower).
The tabulated loads are treated as the PEAK demand of the feeder.
"""
from functools import lru_cache
from typing import Dict, Tuple

import numpy as np
import pandapower as pp

from . import config as C

# (from_bus, to_bus, R [ohm], X [ohm]) -- 1-based bus numbers
BRANCHES = [
    (1, 2, 0.0922, 0.0470), (2, 3, 0.4930, 0.2511), (3, 4, 0.3660, 0.1864),
    (4, 5, 0.3811, 0.1941), (5, 6, 0.8190, 0.7070), (6, 7, 0.1872, 0.6188),
    (7, 8, 0.7114, 0.2351), (8, 9, 1.0300, 0.7400), (9, 10, 1.0440, 0.7400),
    (10, 11, 0.1966, 0.0650), (11, 12, 0.3744, 0.1238), (12, 13, 1.4680, 1.1550),
    (13, 14, 0.5416, 0.7129), (14, 15, 0.5910, 0.5260), (15, 16, 0.7463, 0.5450),
    (16, 17, 1.2890, 1.7210), (17, 18, 0.7320, 0.5740), (2, 19, 0.1640, 0.1565),
    (19, 20, 1.5042, 1.3554), (20, 21, 0.4095, 0.4784), (21, 22, 0.7089, 0.9373),
    (3, 23, 0.4512, 0.3083), (23, 24, 0.8980, 0.7091), (24, 25, 0.8960, 0.7011),
    (6, 26, 0.2030, 0.1034), (26, 27, 0.2842, 0.1447), (27, 28, 1.0590, 0.9337),
    (28, 29, 0.8042, 0.7006), (29, 30, 0.5075, 0.2585), (30, 31, 0.9744, 0.9630),
    (31, 32, 0.3105, 0.3619), (32, 33, 0.3410, 0.5302),
]

# bus -> (P [kW], Q [kvar]) at peak
PEAK_LOADS_KW_KVAR: Dict[int, Tuple[float, float]] = {
    2: (100, 60), 3: (90, 40), 4: (120, 80), 5: (60, 30), 6: (60, 20),
    7: (200, 100), 8: (200, 100), 9: (60, 20), 10: (60, 20), 11: (45, 30),
    12: (60, 35), 13: (60, 35), 14: (120, 80), 15: (60, 10), 16: (60, 20),
    17: (60, 20), 18: (90, 40), 19: (90, 40), 20: (90, 40), 21: (90, 40),
    22: (90, 40), 23: (90, 50), 24: (420, 200), 25: (420, 200), 26: (60, 25),
    27: (60, 25), 28: (60, 20), 29: (120, 70), 30: (200, 600), 31: (150, 70),
    32: (210, 100), 33: (60, 40),
}


def bus_idx(bus_number: int) -> int:
    """Convert the 1-based bus number used in the literature to a pandapower index."""
    if not 1 <= bus_number <= 33:
        raise ValueError(f"Bus number must be in 1..33, got {bus_number}")
    return bus_number - 1


def _build_raw(max_i_ka: float = 999.0) -> pp.pandapowerNet:
    net = pp.create_empty_network(name="IEEE 33-bus", f_hz=50.0)
    for n in range(1, 34):
        pp.create_bus(net, vn_kv=C.BASE_KV, name=f"Bus {n}")
    pp.create_ext_grid(net, bus=bus_idx(1), vm_pu=C.SLACK_VM_PU, name="Substation")
    for k, (f, t, r, x) in enumerate(BRANCHES, start=1):
        # length_km=1 so that r_ohm_per_km == total branch resistance in ohm.
        # c_nf_per_km=0: Baran & Wu data has no shunt capacitance.
        pp.create_line_from_parameters(
            net, from_bus=bus_idx(f), to_bus=bus_idx(t), length_km=1.0,
            r_ohm_per_km=r, x_ohm_per_km=x, c_nf_per_km=0.0, max_i_ka=max_i_ka,
            name=f"Line {k} ({f}-{t})",
        )
    for b, (p_kw, q_kvar) in PEAK_LOADS_KW_KVAR.items():
        pp.create_load(net, bus=bus_idx(b), p_mw=p_kw / 1000.0, q_mvar=q_kvar / 1000.0,
                       name=f"Load {b}")
    return net


@lru_cache(maxsize=1)
def _assumed_ratings_ka() -> Tuple[float, ...]:
    """
    ASSUMED thermal ratings. The Baran & Wu data set does not include any, so we
    size each line as: smallest catalog ampacity >= RATING_MARGIN x (base-case
    peak current). Line-loading results are therefore RELATIVE to this
    assumption and must not be read as real thermal limits.
    """
    net = _build_raw()
    pp.runpp(net, numba=False)
    i_peak_a = np.maximum(net.res_line.i_from_ka, net.res_line.i_to_ka).to_numpy() * 1000.0
    ratings = []
    for i in i_peak_a:
        need = C.RATING_MARGIN * i
        size = next((a for a in C.AMPACITY_CATALOG_A if a >= need), C.AMPACITY_CATALOG_A[-1])
        ratings.append(size / 1000.0)
    return tuple(ratings)


def build_network() -> pp.pandapowerNet:
    """Return a fresh IEEE 33-bus network with the assumed line ratings applied."""
    net = _build_raw()
    net.line["max_i_ka"] = list(_assumed_ratings_ka())
    return net
