"""
Rule-based battery (BESS) dispatch: a fixed-window "solar soak + evening peak shave".

Strategy (deliberately simple and transparent):
  * charge at rated power during the solar window, until SOC reaches SOC_max;
  * discharge at rated power during the evening peak window, until SOC reaches SOC_min;
  * idle otherwise.
The day is repeated until the end-of-day SOC equals the start-of-day SOC
(cyclic steady state), so the battery is not "free energy" from an arbitrary start.

Sign convention (same as pandapower storage): P > 0 = charging (load),
P < 0 = discharging (generation). Energy is tracked on the battery side:
    charging  : E += P * eta * dt
    discharge : E -= P * dt / eta          with eta = sqrt(round-trip efficiency)
"""
from dataclasses import dataclass

import numpy as np

from .config import Study


@dataclass
class BessSchedule:
    p_mw: np.ndarray            # grid-side power per hour, + = charging
    energy_mwh: np.ndarray      # stored energy at END of each hour
    soc: np.ndarray             # state of charge at END of each hour [0..1]
    soc_start: float            # SOC at 00:00
    conversion_loss_mwh: float  # round-trip losses over the day


def schedule_bess(s: Study, dt_h: float = 1.0) -> BessSchedule:
    if s.bess_power_mw <= 0 or s.bess_energy_mwh <= 0:
        return BessSchedule(np.zeros(24), np.zeros(24), np.zeros(24), 0.0, 0.0)
    if not 0 < s.bess_roundtrip_eff <= 1:
        raise ValueError("Round-trip efficiency must be in (0, 1]")
    if not 0 <= s.bess_soc_min < s.bess_soc_max <= 1:
        raise ValueError("Need 0 <= SOC_min < SOC_max <= 1")
    if set(s.bess_charge_hours) & set(s.bess_discharge_hours):
        raise ValueError("Charge and discharge windows must not overlap")

    eta = np.sqrt(s.bess_roundtrip_eff)
    e_min = s.bess_soc_min * s.bess_energy_mwh
    e_max = s.bess_soc_max * s.bess_energy_mwh

    def one_day(e0):
        e, p, en = e0, np.zeros(24), np.zeros(24)
        for h in range(24):
            if h in s.bess_charge_hours:
                p_ch = min(s.bess_power_mw, max(e_max - e, 0.0) / (eta * dt_h))
                e += p_ch * eta * dt_h
                p[h] = p_ch
            elif h in s.bess_discharge_hours:
                p_dis = min(s.bess_power_mw, max(e - e_min, 0.0) * eta / dt_h)
                e -= p_dis * dt_h / eta
                p[h] = -p_dis
            en[h] = e
        return p, en, e

    e0 = e_min
    for _ in range(10):                      # converge to cyclic steady state
        p, en, e_end = one_day(e0)
        if abs(e_end - e0) < 1e-9:
            break
        e0 = e_end
    p, en, e_end = one_day(e0)

    charged = p[p > 0].sum() * dt_h
    discharged = -p[p < 0].sum() * dt_h
    loss = charged - discharged - (e_end - e0)   # grid in - grid out - change in stored energy
    return BessSchedule(p, en, en / s.bess_energy_mwh, e0 / s.bess_energy_mwh, float(loss))
