"""
Short one-at-a-time sensitivity study. Each sweep changes ONE parameter and keeps
all others at the defaults in config.Study. Results are specific to the assumed
profiles and the IEEE 33-bus feeder.
"""
import dataclasses
from typing import Iterable

import pandas as pd

from . import config as C
from .metrics import kpis
from .simulate import simulate, LABELS


def _row(res, **extra) -> dict:
    k = kpis(res)
    return {**extra,
            "V_min [pu]": k["V_min [pu]"],
            "V_min evening [pu]": k["V_min evening 18-22h [pu]"],
            "V_max [pu]": k["V_max [pu]"],
            "Undervoltage bus-hours": k["Undervoltage bus-hours (<0.95)"],
            "Overvoltage bus-hours": k["Overvoltage bus-hours (>1.05)"],
            "Network losses [kWh/day]": k["Network losses [kWh/day]"],
            "Peak import [MW]": k["Peak substation import [MW]"],
            "Max line loading [%]": k["Max line loading [% of assumed rating]"]}


def sweep_ev(scales: Iterable[float] = (0.0, 0.5, 1.0, 1.5, 2.0)) -> pd.DataFrame:
    """EV charging energy multiplier, on scenario S2 (PV + EV, no battery)."""
    return pd.DataFrame([_row(simulate("S2_pv_ev", dataclasses.replace(C.Study(), ev_scale=s)),
                              **{"EV energy x": s}) for s in scales])


def sweep_pv(scales: Iterable[float] = (0.0, 1.0, 2.0, 3.0, 4.0)) -> pd.DataFrame:
    """PV capacity multiplier, on scenario S2 (PV + EV, no battery)."""
    return pd.DataFrame([_row(simulate("S2_pv_ev", dataclasses.replace(C.Study(), pv_scale=s)),
                              **{"PV capacity x": s,
                                 "PV total [MWp]": s * len(C.Study().pv_buses) * C.Study().pv_kwp_per_site / 1000})
                         for s in scales])


def sweep_bess(powers=(0.5, 1.0, 1.5, 2.0), energies=(1.0, 2.0, 4.0, 6.0)) -> pd.DataFrame:
    """BESS power x energy grid, on scenario S3. Compared against S2 by the caller."""
    rows = []
    for p in powers:
        for e in energies:
            s = dataclasses.replace(C.Study(), bess_power_mw=p, bess_energy_mwh=e)
            rows.append(_row(simulate("S3_pv_ev_bess", s), **{"BESS [MW]": p, "BESS [MWh]": e}))
    return pd.DataFrame(rows)


def sweep_bess_bus(buses=(8, 14, 18, 25, 30, 33)) -> pd.DataFrame:
    """Where to put the battery (same 1 MW / 4 MWh)."""
    return pd.DataFrame([_row(simulate("S3_pv_ev_bess", dataclasses.replace(C.Study(), bess_bus=b)),
                              **{"BESS bus": b}) for b in buses])
