"""
Model validation checks. These run at the end of main.py and as pytest tests.

What they prove: the network data and solver reproduce published values, and the
power balance closes. What they do NOT prove: that the synthetic profiles or the
DER sizes are realistic.
"""
import numpy as np
import pandapower as pp
import pandapower.networks as pn

from . import config as C
from .metrics import energy_balance_error_mw
from .network import PEAK_LOADS_KW_KVAR, _build_raw

# Published base case (Baran & Wu 1989 data at peak load, 12.66 kV, no DER).
LIT_LOSS_KW = 202.67
LIT_VMIN_PU = 0.9131
LIT_VMIN_BUS = 18


def check_total_load() -> bool:
    p = sum(v[0] for v in PEAK_LOADS_KW_KVAR.values()); q = sum(v[1] for v in PEAK_LOADS_KW_KVAR.values())
    return p == 3715 and q == 2300


def check_against_literature(tol_kw=0.5, tol_pu=0.0005) -> dict:
    net = _build_raw(); pp.runpp(net, numba=False)
    loss = net.res_line.pl_mw.sum() * 1000
    vmin = net.res_bus.vm_pu.min(); bus = int(net.res_bus.vm_pu.idxmin()) + 1
    return {"loss_kw": float(loss), "vmin_pu": float(vmin), "vmin_bus": bus,
            "ok": abs(loss - LIT_LOSS_KW) < tol_kw and abs(vmin - LIT_VMIN_PU) < tol_pu and bus == LIT_VMIN_BUS}


def check_against_pandapower_builtin(tol=1e-6) -> dict:
    """Compare our hand-entered data with pandapower's bundled case33bw."""
    mine = _build_raw(); ref = pn.case33bw()
    pp.runpp(mine, numba=False); pp.runpp(ref, numba=False)
    dv = float(np.max(np.abs(mine.res_bus.vm_pu.to_numpy() - ref.res_bus.vm_pu.to_numpy())))
    return {"max_voltage_diff_pu": dv, "ok": dv < tol}


def check_energy_balance(results, tol_mw=1e-6) -> dict:
    err = {n: energy_balance_error_mw(r) for n, r in results.items()}
    return {"max_error_mw": err, "ok": all(e < tol_mw for e in err.values())}


def check_bess_energy(results) -> dict:
    r = results["S3_pv_ev_bess"]
    soc_ok = bool(np.all(r.bess_soc >= C.Study().bess_soc_min - 1e-9) and np.all(r.bess_soc <= C.Study().bess_soc_max + 1e-9))
    p_ok = bool(np.all(np.abs(r.bess_mw) <= C.Study().bess_power_mw + 1e-9))
    return {"soc_within_limits": soc_ok, "power_within_rating": p_ok, "ok": soc_ok and p_ok}


def run_all_checks(results) -> dict:
    out = {"total_load_matches_3715kW_2300kvar": check_total_load(),
           "literature_base_case": check_against_literature(),
           "matches_pandapower_case33bw": check_against_pandapower_builtin(),
           "energy_balance": check_energy_balance(results),
           "bess_limits": check_bess_energy(results)}
    return out
