"""
Central place for every study assumption.

IMPORTANT: every number in this file is an ASSUMPTION made for a teaching /
portfolio study. None of it is measured data. Change it here and re-run
`python main.py` to see how the conclusions move.

Bus numbers are 1-based, exactly as in Baran & Wu (1989).
"""
from dataclasses import dataclass
from typing import Tuple

# ---------------------------------------------------------------- network ----
BASE_KV = 12.66          # nominal voltage of the IEEE 33-bus feeder [kV]
SLACK_VM_PU = 1.00       # substation voltage setpoint [per-unit] (assumption)
V_MIN_PU = 0.95          # lower voltage limit [pu] (common planning limit)
V_MAX_PU = 1.05          # upper voltage limit [pu]
RATING_MARGIN = 1.50     # ampacity = margin x base-case peak current (assumption:
                         # the original data set has NO thermal ratings)
AMPACITY_CATALOG_A = (100, 150, 200, 250, 300, 400, 500, 600)  # assumed standard sizes


@dataclass(frozen=True)
class Study:
    """All knobs of one simulation run. `dataclasses.replace` is used for sensitivities."""
    # --- solar PV (assumption) ---
    pv_buses: Tuple[int, ...] = (6, 14, 24, 30)
    pv_kwp_per_site: float = 500.0        # installed capacity per site [kWp]
    pv_peak_cf: float = 0.85              # peak output as fraction of kWp (clear day)
    pv_scale: float = 1.0                 # multiplier used in sensitivity runs
    # --- EV charging hubs (assumption) ---
    ev_buses: Tuple[int, ...] = (8, 18, 25, 33)
    ev_vehicles_per_hub: int = 250
    ev_kwh_per_vehicle_day: float = 12.0  # AC-side energy per vehicle per day [kWh]
    ev_pf: float = 0.98                   # charger power factor (lagging)
    ev_scale: float = 1.0                 # multiplier used in sensitivity runs
    # --- battery energy storage system (BESS) (assumption) ---
    bess_bus: int = 18
    bess_power_mw: float = 1.0
    bess_energy_mwh: float = 4.0
    bess_roundtrip_eff: float = 0.90
    bess_soc_min: float = 0.10
    bess_soc_max: float = 0.90
    bess_charge_hours: Tuple[int, ...] = (11, 12, 13)           # around PV peak
    bess_discharge_hours: Tuple[int, ...] = (19, 20, 21)        # evening peak
