"""Figures. Every figure is generated from simulation results, never hard-coded."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from . import config as C
from .profiles import ev_profile, load_profile, pv_profile
from .simulate import LABELS

COLORS = {"S0_base": "#444444", "S1_pv": "#e69f00", "S2_pv_ev": "#d55e00", "S3_pv_ev_bess": "#0072b2"}
plt.rcParams.update({"figure.dpi": 130, "axes.grid": True, "grid.alpha": 0.3, "font.size": 9})


def _save(fig, out: Path, name: str):
    out.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out / name, bbox_inches="tight")
    plt.close(fig)


def fig_profiles(results, out: Path):
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.4))
    h = np.arange(24)
    ax[0].plot(h, load_profile(), color="#444"); ax[0].set_title("Assumed feeder demand (fraction of peak)")
    ax[1].plot(h, pv_profile(), color="#e69f00"); ax[1].set_title("Assumed PV output (fraction of kWp)")
    ax[2].plot(h, ev_profile() * 100, color="#d55e00"); ax[2].set_title("Assumed EV charging (% of daily energy)")
    for a in ax: a.set_xlabel("Hour of day"); a.set_xticks(range(0, 24, 3))
    fig.suptitle("Synthetic input profiles (illustrative, not measured data)", y=1.03)
    _save(fig, out, "01_input_profiles.png")


def fig_voltage_profiles(results, out: Path):
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.8), sharey=True)
    for ax, hour in zip(axes, (12, 19)):
        for name, r in results.items():
            ax.plot(r.vm.columns, r.vm.loc[hour].to_numpy(), marker="o", ms=3,
                    color=COLORS[name], label=LABELS[name])
        ax.axhline(C.V_MIN_PU, color="r", ls="--", lw=1); ax.axhline(C.V_MAX_PU, color="r", ls="--", lw=1)
        ax.set_title(f"Voltage profile along bus number at {hour:02d}:00")
        ax.set_xlabel("Bus number")
    axes[0].set_ylabel("Voltage magnitude [pu]"); axes[0].legend(fontsize=8)
    _save(fig, out, "02_voltage_profile_by_bus.png")


def fig_min_voltage(results, out: Path):
    fig, ax = plt.subplots(figsize=(8, 3.8))
    for name, r in results.items():
        ax.plot(range(24), r.vm.drop(columns=[1]).min(axis=1), marker="o", ms=3,
                color=COLORS[name], label=LABELS[name])
    ax.axhline(C.V_MIN_PU, color="r", ls="--", lw=1, label="0.95 pu limit")
    ax.set_xlabel("Hour of day"); ax.set_ylabel("Lowest bus voltage [pu]")
    ax.set_title("Minimum voltage on the feeder over 24 h"); ax.legend(fontsize=8)
    _save(fig, out, "03_min_voltage_vs_hour.png")


def fig_losses(results, out: Path):
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.8), gridspec_kw={"width_ratios": [2, 1]})
    for name, r in results.items():
        ax[0].plot(range(24), r.losses_kw, marker="o", ms=3, color=COLORS[name], label=LABELS[name])
    ax[0].set_xlabel("Hour of day"); ax[0].set_ylabel("Network losses [kW]"); ax[0].legend(fontsize=8)
    ax[0].set_title("Hourly I$^2$R losses")
    names = list(results)
    daily = [results[n].losses_kw.sum() for n in names]
    conv = [results[n].bess_conv_loss_kwh for n in names]
    x = np.arange(len(names))
    ax[1].bar(x, daily, color=[COLORS[n] for n in names], label="Network (I$^2$R)")
    ax[1].bar(x, conv, bottom=daily, color="#999999", label="Battery conversion")
    ax[1].set_xticks(x); ax[1].set_xticklabels(["S0", "S1", "S2", "S3"])
    ax[1].set_ylabel("Energy [kWh/day]"); ax[1].set_title("Daily losses"); ax[1].legend(fontsize=8)
    _save(fig, out, "04_losses.png")


def fig_line_loading(results, out: Path):
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
    for name, r in results.items():
        ax[0].plot(r.line_loading.columns, r.line_loading.max(axis=0), marker="o", ms=3,
                   color=COLORS[name], label=LABELS[name])
        ax[1].plot(range(24), r.line_loading.max(axis=1), marker="o", ms=3, color=COLORS[name])
    ax[0].set_xlabel("Line number"); ax[0].set_ylabel("Max loading over 24 h [% of assumed rating]")
    ax[0].set_title("Peak loading per line"); ax[0].legend(fontsize=8)
    for a in ax: a.axhline(100, color="r", ls="--", lw=1)
    ax[1].set_xlabel("Hour of day"); ax[1].set_ylabel("Most loaded line [%]")
    ax[1].set_title("Most loaded line vs hour")
    fig.suptitle("Ratings are ASSUMED (1.5 x base-case peak current, rounded up)", y=1.03, fontsize=9)
    _save(fig, out, "05_line_loading.png")


def fig_substation(results, out: Path):
    fig, ax = plt.subplots(figsize=(8, 3.8))
    for name, r in results.items():
        ax.plot(range(24), r.p_import_mw, marker="o", ms=3, color=COLORS[name], label=LABELS[name])
    ax.set_xlabel("Hour of day"); ax.set_ylabel("Substation active power [MW]")
    ax.set_title("Power drawn from the substation"); ax.legend(fontsize=8)
    _save(fig, out, "06_substation_power.png")


def fig_bess(results, out: Path):
    r = results["S3_pv_ev_bess"]
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.6))
    ax[0].bar(range(24), r.bess_mw, color=np.where(r.bess_mw >= 0, "#0072b2", "#cc79a7"))
    ax[0].set_title("BESS power (+ charging / - discharging) [MW]"); ax[0].set_xlabel("Hour of day")
    ax[1].plot(range(24), r.bess_soc * 100, color="#0072b2", marker="o", ms=3)
    ax[1].set_title("BESS state of charge, end of hour [%]"); ax[1].set_xlabel("Hour of day")
    _save(fig, out, "07_bess_operation.png")


def fig_kpi_bars(table, out: Path):
    fig, ax = plt.subplots(1, 4, figsize=(14, 3.4))
    cols = [("V_min [pu]", "Lowest voltage [pu]"),
            ("Network losses [kWh/day]", "Network losses [kWh/day]"),
            ("Peak substation import [MW]", "Peak import [MW]"),
            ("Max line loading [% of assumed rating]", "Max line loading [%]")]
    for a, (c, t) in zip(ax, cols):
        a.bar(["S0", "S1", "S2", "S3"], table[c].to_numpy(), color=list(COLORS.values()))
        a.set_title(t)
    _save(fig, out, "08_kpi_summary.png")


def fig_sensitivity(ev, pv, bess, bus, base_s2, out: Path):
    fig, ax = plt.subplots(2, 3, figsize=(14, 7))
    ax[0, 0].plot(ev["EV energy x"], ev["V_min [pu]"], marker="o", color=COLORS["S2_pv_ev"])
    ax[0, 0].axhline(C.V_MIN_PU, color="r", ls="--", lw=1); ax[0, 0].set_title("EV energy vs lowest voltage")
    ax[0, 0].set_xlabel("EV daily energy (x default)"); ax[0, 0].set_ylabel("V_min [pu]")
    ax[0, 1].plot(ev["EV energy x"], ev["Network losses [kWh/day]"], marker="o", color=COLORS["S2_pv_ev"])
    ax[0, 1].set_title("EV energy vs daily network losses"); ax[0, 1].set_xlabel("EV daily energy (x default)")
    ax[0, 1].set_ylabel("kWh/day")
    ax[0, 2].plot(pv["PV total [MWp]"], pv["V_max [pu]"], marker="o", color=COLORS["S1_pv"], label="V_max")
    ax[0, 2].axhline(C.V_MAX_PU, color="r", ls="--", lw=1)
    ax[0, 2].set_title("PV capacity vs highest voltage (with EV)"); ax[0, 2].set_xlabel("Total PV [MWp]")
    ax[0, 2].set_ylabel("V_max [pu]")
    ax[1, 0].plot(pv["PV total [MWp]"], pv["Network losses [kWh/day]"], marker="o", color=COLORS["S1_pv"])
    ax[1, 0].set_title("PV capacity vs daily network losses"); ax[1, 0].set_xlabel("Total PV [MWp]")
    ax[1, 0].set_ylabel("kWh/day")
    for p, g in bess.groupby("BESS [MW]"):
        ax[1, 1].plot(g["BESS [MWh]"], g["Peak import [MW]"], marker="o", label=f"{p} MW")
    ax[1, 1].axhline(base_s2["Peak substation import [MW]"], color="k", ls=":", lw=1, label="No battery (S2)")
    ax[1, 1].set_title("Battery size vs peak substation import"); ax[1, 1].set_xlabel("Battery energy [MWh]")
    ax[1, 1].set_ylabel("MW"); ax[1, 1].legend(fontsize=8)
    ax[1, 2].bar(bus["BESS bus"].astype(str), bus["V_min evening [pu]"], color=COLORS["S3_pv_ev_bess"])
    ax[1, 2].axhline(base_s2["V_min evening 18-22h [pu]"], color="k", ls=":", lw=1, label="No battery (S2)")
    ax[1, 2].set_ylim(bus["V_min evening [pu]"].min() - 0.01, bus["V_min evening [pu]"].max() + 0.01)
    ax[1, 2].set_title("Battery location vs evening lowest voltage"); ax[1, 2].set_xlabel("BESS bus")
    ax[1, 2].set_ylabel("V_min 18-22h [pu]"); ax[1, 2].legend(fontsize=8)
    _save(fig, out, "09_sensitivity.png")
