|                                        | S0 Base    | S1 + PV    | S2 + PV + EV   | S3 + PV + EV + BESS   |
|:---------------------------------------|:-----------|:-----------|:---------------|:----------------------|
| V_min [pu]                             | 0.9131     | 0.9131     | 0.8607         | 0.8745                |
| V_min bus / hour                       | 18 / 19:00 | 18 / 19:00 | 18 / 19:00     | 18 / 13:00            |
| V_min evening 18-22h [pu]              | 0.9131     | 0.9131     | 0.8607         | 0.8774                |
| V_max [pu]                             | 0.9984     | 0.9986     | 0.9985         | 0.9985                |
| V_max bus / hour                       | 2 / 03:00  | 2 / 11:00  | 2 / 11:00      | 2 / 10:00             |
| Undervoltage bus-hours (<0.95)         | 297        | 150        | 239            | 287                   |
| Overvoltage bus-hours (>1.05)          | 0          | 0          | 0              | 0                     |
| Network losses [kWh/day]               | 2896.8     | 2234.3     | 3532.4         | 3535.4                |
| Peak loss [kW]                         | 202.7      | 202.7      | 423.8          | 339.3                 |
| Loss share of import [%]               | 4.05       | 3.86       | 4.97           | 4.95                  |
| Battery conversion loss [kWh/day]      | 0.0        | 0.0        | 0.0            | 300.0                 |
| System losses incl. battery [kWh/day]  | 2896.8     | 2234.3     | 3532.4         | 3835.4                |
| Max line loading [% of assumed rating] | 65.4       | 65.4       | 96.8           | 84.7                  |
| Line-hours above 100%                  | 0          | 0          | 0              | 0                     |
| Peak substation import [MW]            | 3.918      | 3.918      | 5.537          | 4.991                 |
| Energy imported [MWh/day]              | 71.51      | 57.83      | 71.12          | 71.43                 |