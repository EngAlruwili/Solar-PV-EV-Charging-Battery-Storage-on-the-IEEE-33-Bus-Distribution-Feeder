# LinkedIn post (English) - edit the bracketed parts before posting

---

I built a small power-systems project: what happens to a distribution feeder when you add solar PV and EV charging, and can a battery help?

I used the standard IEEE 33-bus feeder, modelled it in Python with pandapower, and ran a 24-hour simulation for four cumulative cases: base, + solar, + EV charging, + battery.

What the simulation showed (under my synthetic assumptions, not real utility data):
- Solar cut daily network losses by about 23%, but gave no help at the evening peak.
- Evening-concentrated EV charging was the main stress: the lowest voltage dropped from 0.913 to 0.861 pu and peak substation power rose about 41%.
- A 1 MW / 4 MWh battery with a simple time-window schedule cut peak power by about 10% and lifted evening voltage, but it also created new midday undervoltage at a weak bus. A naive schedule is not enough; dispatch and location need to be network-aware.

Along the way: I validated the base case against published values (202.7 kW loss, 0.9131 pu minimum voltage), and a cross-check against a reference model caught two data-entry mistakes of mine.

Limits, stated plainly: synthetic profiles, one day, no inverter control, and assumed line ratings. It is a learning project, not a utility study.

Skills this project practised: power-flow analysis, distribution-network modelling, DER integration, Python (pandapower, pandas, matplotlib), testing and validation, and technical documentation.

[Optional, only if true: I used an AI assistant to help draft code and documentation, then ran, tested and reviewed everything myself.]

Code, results and a full report: [GitHub link]
Next steps I want to try: real load data, Volt-VAR control for PV, and optimised battery dispatch.

#PowerSystems #ElectricalEngineering #SolarEnergy #EVCharging #EnergyStorage #Python #SmartGrid #pandapower

---

## Notes before posting
- Only keep the AI-assistance line if it is accurate, and make sure you can explain every part of the code and results in an interview.
- Do not add claims like "optimised", "validated against real data" or "reduces losses by X%" beyond what the report states.
- Attach 1-2 figures: `figures/02_voltage_profile_by_bus.png` and `figures/09_sensitivity.png`.
