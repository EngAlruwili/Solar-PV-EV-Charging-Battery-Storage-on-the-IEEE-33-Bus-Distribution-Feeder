# Technical Report: Impact of Solar PV and EV Charging on a Distribution Feeder, and the Role of Battery Storage

*Study on the IEEE 33-bus feeder using Python and pandapower. Every result below was produced by the code in this repository; nothing was copied from other studies. Inputs are labelled as **Fact** (published), **Assumption** (my choice) or **Result** (computed).*

## 1. Executive summary

**Problem.** Distribution feeders were designed for one-way power flow from the substation. Rooftop/ground solar PV can push power backwards and raise voltage at midday, while EV charging adds a large, often evening-concentrated load that can pull voltage down and overload lines. A battery energy storage system (BESS) is one proposed remedy.

**Why it matters.** Voltage limits, losses and conductor ratings decide how much PV and EV load a feeder can host before costly reinforcement is needed.

**Objectives.** (1) Build the IEEE 33-bus feeder in pandapower and verify it against published values. (2) Compare four cumulative scenarios: base, +PV, +EV, +BESS. (3) Quantify voltage, losses, line loading and substation power. (4) Run a short sensitivity study on EV energy, PV capacity, battery size and battery location.

**What makes it useful.** It is fully reproducible, validated against a published base case, separates facts from assumptions, and reports a non-obvious trade-off: a simple time-window battery reduces evening stress but can create midday undervoltage at a weak bus.

## 2. Technical background (terms explained)

- **Power flow (load flow):** solves the steady-state voltages and currents of a network for given loads and generation. Here: AC Newton-Raphson via pandapower.
- **Per-unit (pu):** voltage divided by its nominal value; 1.00 pu = 12.66 kV here.
- **Radial distribution feeder:** a tree-shaped network with one source (the substation); power normally flows outward.
- **Voltage drop:** along a line, approximately dV ~ (R*P + X*Q) / V. This feeder has high R/X ratios, so **active power** strongly affects voltage, which is why PV, EV and battery active power matter so much.
- **Losses:** I^2 R heating in conductors; P_loss = 3 * I^2 * R per line. They grow with the square of current.
- **Solar PV:** produces power only in daylight and (here) at unity power factor. Reduces net load and losses, can cause overvoltage when generation exceeds local load.
- **EV charging:** an added load; the key quantity is its coincidence with the existing evening peak.
- **BESS:** stores energy and can shift it in time. Round-trip efficiency below 100% means it consumes net energy.
- **Quasi-static time series (QSTS):** many steady-state power flows, one per time step; no dynamics.

## 3. Scope and assumptions

**In scope:** one 24-hour day, balanced three-phase feeder (single-phase equivalent), hourly steps, four scenarios, one-at-a-time sensitivities.
**Out of scope:** unbalance, protection, harmonics, transient behaviour, tap changers, capacitors, reconfiguration, economics, uncertainty.

| Item | Value | Type |
|---|---|---|
| Feeder topology, R, X, peak loads | Baran & Wu (1989); 12.66 kV; 3715 kW, 2300 kvar; tie lines excluded | Fact |
| Substation voltage | 1.00 pu | Assumption |
| Voltage limits | 0.95-1.05 pu | Convention |
| Line ratings | 1.5 x base-case peak current, rounded up to {100,150,200,250,300,400,500,600} A | Assumption |
| Load profile | evening-peaking, peak = 1.0 at 19:00-20:00 | Assumption (synthetic) |
| PV | 4 x 500 kWp at buses 6, 14, 24, 30; peak output 0.85 x kWp; half-sine 06:00-18:00 | Assumption |
| EV | 4 hubs at buses 8, 18, 25, 33; 250 vehicles x 12 kWh/day each = 12 MWh/day; pf 0.98; evening-weighted profile | Assumption |
| BESS | 1 MW / 4 MWh at bus 18; 90% round trip; SOC 10-90%; charge 11-14h, discharge 19-22h; unity pf | Assumption |

**The simulation results depend on these data and assumptions. They are not predictions for any real network.** Profiles are not measured, and the loads/DER positions were chosen for illustration (EV hubs deliberately include weak-end buses).

## 4. Methodology

1. **Build the network.** 33 buses, 32 lines (R, X in ohm, no shunt capacitance), one external grid at bus 1, 32 loads. Check against the published base case.
2. **Assign line ratings** (assumption above) so loading percentages can be computed.
3. **Create hourly inputs.** Load(h) = peak load x f_load(h). PV(h) = kWp x CF_peak x f_pv(h). EV hub power(h) = daily hub energy x share(h) (dt = 1 h, so MWh/h = MW), Q = P x tan(arccos pf).
4. **Battery schedule** (rule-based, cyclic): in the charge window, P = min(P_rated, headroom / (eta * dt)); in the discharge window, P = min(P_rated, (E - E_min) * eta / dt); idle otherwise. eta = sqrt(round-trip). The day is repeated until end-of-day SOC equals start-of-day SOC.
5. **Run scenarios S0-S3.** For each hour, update loads/sources and solve an AC power flow.
6. **Compute KPIs** (Section 5), **run sensitivities** (Section 7), **validate** (Section 8).

## 5. Key performance indicators

| KPI | Definition | Unit |
|---|---|---|
| V_min, V_max | min / max bus voltage over 24 h, slack bus excluded | pu |
| Under/over-voltage bus-hours | count of (bus, hour) pairs below 0.95 / above 1.05 | count |
| Network losses | E_loss = sum over hours and lines of P_loss(h) x 1 h | kWh/day |
| Loss share | E_loss / E_import x 100 | % |
| Max line loading | max over lines and hours of I / I_rated x 100 (I_rated assumed) | % |
| Peak substation import | max over hours of active power at the slack bus | MW |
| System losses | network losses + battery round-trip losses | kWh/day |

Check applied every hour: P_import = P_load + P_EV + P_battery(charging positive) - P_PV + P_loss.

## 6. Results (actual output of `python main.py`)

|                                        | S0 Base    | S1 + PV    | S2 + PV + EV   | S3 + PV + EV + BESS   |
|:---------------------------------------|:-----------|:-----------|:---------------|:----------------------|
| V_min [pu]                             | 0.9131     | 0.9131     | 0.8607         | 0.8745                |
| V_min bus / hour                       | 18 / 19:00 | 18 / 19:00 | 18 / 19:00     | 18 / 13:00            |
| V_min evening 18-22h [pu]              | 0.9131     | 0.9131     | 0.8607         | 0.8774                |
| V_max [pu]                             | 0.9984     | 0.9986     | 0.9985         | 0.9985                |
| Undervoltage bus-hours (<0.95)         | 297        | 150        | 239            | 287                   |
| Overvoltage bus-hours (>1.05)          | 0          | 0          | 0              | 0                     |
| Network losses [kWh/day]               | 2896.8     | 2234.3     | 3532.4         | 3535.4                |
| Peak loss [kW]                         | 202.7      | 202.7      | 423.8          | 339.3                 |
| Loss share of import [%]               | 4.05       | 3.86       | 4.97           | 4.95                  |
| Battery conversion loss [kWh/day]      | 0.0        | 0.0        | 0.0            | 300.0                 |
| System losses incl. battery [kWh/day]  | 2896.8     | 2234.3     | 3532.4         | 3835.4                |
| Max line loading [% of assumed rating] | 65.4       | 65.4       | 96.8           | 84.7                  |
| Peak substation import [MW]            | 3.918      | 3.918      | 5.537          | 4.991                 |
| Energy imported [MWh/day]              | 71.51      | 57.83      | 71.12          | 71.43                 |

Scenario energy context: baseline demand 68.6 MWh/day; PV energy 13.0 MWh/day (peak 1.69 MW); EV energy 12.0 MWh/day (peak 1.40 MW).

**Interpretation.**
1. *Base:* the feeder already violates 0.95 pu at peak (0.9131 pu at bus 18, loss 202.7 kW), matching the published values (Section 8).
2. *PV:* daily network losses fall about 23% and imported energy about 19%. Voltage improves around midday but nothing changes from 18:00 to 22:00 because PV output is zero. No overvoltage occurs at 2 MWp; see sensitivity for where it starts.
3. *EV:* with evening-weighted charging, the lowest voltage falls from 0.9131 to 0.8607 pu, peak import rises from 3.92 to 5.54 MW (+41%), peak loss rises from 202.7 to 423.8 kW, and the most loaded line reaches 96.8% of its **assumed** rating.
4. *Battery:* reduces peak import to 4.99 MW (-10%), peak loss to 339.3 kW (-20%), most loaded line to 84.7%, and raises voltage at the former worst hours (19:00-20:00) from 0.8607 to 0.8984 pu. Trade-offs: daily network losses do not fall (3532.4 to 3535.4 kWh), battery conversion adds 300 kWh/day, so system losses rise about 9%; and charging 1 MW at bus 18 during 11:00-13:00 pulls midday voltage down to about 0.875 pu (it was 0.956 pu in S2), increasing under-voltage bus-hours from 239 to 287. The worst evening hour moves to 18:00 (0.8774 pu), just before the discharge window.

**What I can and cannot claim.** The battery clearly shaves the peak in this model. Whether the schedule is "good" depends on the assumed profiles, and the midday undervoltage shows that a time-only rule ignores network conditions.

## 7. Sensitivity (one parameter at a time; others at default)

**EV daily energy (scenario S2).**

|   EV energy x |   V_min [pu] |   V_min evening [pu] |   V_max [pu] |   Undervoltage bus-hours |   Overvoltage bus-hours |   Network losses [kWh/day] |   Peak import [MW] |   Max line loading [%] |
|--------------:|-------------:|---------------------:|-------------:|-------------------------:|------------------------:|---------------------------:|-------------------:|-----------------------:|
|           0   |       0.9131 |               0.9131 |       0.9986 |                      150 |                       0 |                     2234.3 |              3.918 |                   65.4 |
|           0.5 |       0.8877 |               0.8877 |       0.9985 |                      199 |                       0 |                     2817.6 |              4.713 |                   77.6 |
|           1   |       0.8607 |               0.8607 |       0.9985 |                      239 |                       0 |                     3532.4 |              5.537 |                   96.8 |
|           1.5 |       0.8318 |               0.8318 |       0.9984 |                      283 |                       0 |                     4395.1 |              6.395 |                  117.7 |
|           2   |       0.8007 |               0.8007 |       0.9983 |                      315 |                       0 |                     5427   |              7.294 |                  140.1 |

**PV capacity (scenario S2, PV + EV).**

|   PV capacity x |   PV total [MWp] |   V_min [pu] |   V_min evening [pu] |   V_max [pu] |   Undervoltage bus-hours |   Overvoltage bus-hours |   Network losses [kWh/day] |   Peak import [MW] |   Max line loading [%] |
|----------------:|-----------------:|-------------:|---------------------:|-------------:|-------------------------:|------------------------:|---------------------------:|-------------------:|-----------------------:|
|               0 |                0 |       0.8607 |               0.8607 |       0.9983 |                      371 |                       0 |                     4312.9 |              5.537 |                   96.8 |
|               1 |                2 |       0.8607 |               0.8607 |       0.9985 |                      239 |                       0 |                     3532.4 |              5.537 |                   96.8 |
|               2 |                4 |       0.8607 |               0.8607 |       0.9994 |                      206 |                       0 |                     3275.1 |              5.537 |                   96.8 |
|               3 |                6 |       0.8607 |               0.8607 |       1.0292 |                      187 |                       0 |                     3473.3 |              5.537 |                   96.8 |
|               4 |                8 |       0.8607 |               0.8607 |       1.0588 |                      183 |                      16 |                     4074.9 |              5.537 |                   96.8 |

**Battery size (scenario S3).**

|   BESS [MW] |   BESS [MWh] |   V_min [pu] |   V_min evening [pu] |   V_max [pu] |   Undervoltage bus-hours |   Overvoltage bus-hours |   Network losses [kWh/day] |   Peak import [MW] |   Max line loading [%] |
|------------:|-------------:|-------------:|---------------------:|-------------:|-------------------------:|------------------------:|---------------------------:|-------------------:|-----------------------:|
|         0.5 |            1 |       0.875  |               0.875  |       0.9985 |                      257 |                       0 |                     3431.5 |              5.214 |                   86.6 |
|         0.5 |            2 |       0.8774 |               0.8774 |       0.9985 |                      275 |                       0 |                     3383.2 |              4.991 |                   84.7 |
|         0.5 |            4 |       0.8774 |               0.8774 |       0.9985 |                      275 |                       0 |                     3383.2 |              4.991 |                   84.7 |
|         0.5 |            6 |       0.8774 |               0.8774 |       0.9985 |                      275 |                       0 |                     3383.2 |              4.991 |                   84.7 |
|         1   |            1 |       0.8607 |               0.8607 |       0.9985 |                      254 |                       0 |                     3497.7 |              5.537 |                   96.8 |
|         1   |            2 |       0.875  |               0.875  |       0.9985 |                      269 |                       0 |                     3480.6 |              5.042 |                   86.6 |
|         1   |            4 |       0.8745 |               0.8774 |       0.9985 |                      287 |                       0 |                     3535.4 |              4.991 |                   84.7 |
|         1   |            6 |       0.8745 |               0.8774 |       0.9985 |                      287 |                       0 |                     3535.4 |              4.991 |                   84.7 |
|         1.5 |            1 |       0.8607 |               0.8607 |       0.9985 |                      254 |                       0 |                     3497.7 |              5.537 |                   96.8 |
|         1.5 |            2 |       0.8236 |               0.8623 |       0.9985 |                      254 |                       0 |                     3689.8 |              5.514 |                  115.1 |
|         1.5 |            4 |       0.8236 |               0.8774 |       0.9985 |                      270 |                       0 |                     3856.1 |              4.998 |                  115.1 |
|         1.5 |            6 |       0.8227 |               0.8774 |       0.9985 |                      281 |                       0 |                     4029.1 |              4.991 |                  115.5 |
|         2   |            1 |       0.8607 |               0.8607 |       0.9985 |                      254 |                       0 |                     3497.7 |              5.537 |                   96.8 |
|         2   |            2 |       0.8016 |               0.8607 |       0.9985 |                      250 |                       0 |                     3778.3 |              5.537 |                  128.4 |
|         2   |            4 |       0.7594 |               0.875  |       1.006  |                      264 |                       0 |                     4116.9 |              5.042 |                  153.3 |
|         2   |            6 |       0.7594 |               0.8774 |       1.006  |                      268 |                       0 |                     4557.8 |              4.991 |                  153.3 |

**Battery location, 1 MW / 4 MWh (scenario S3).**

|   BESS bus |   V_min [pu] |   V_min evening [pu] |   V_max [pu] |   Undervoltage bus-hours |   Overvoltage bus-hours |   Network losses [kWh/day] |   Peak import [MW] |   Max line loading [%] |
|-----------:|-------------:|---------------------:|-------------:|-------------------------:|------------------------:|---------------------------:|-------------------:|-----------------------:|
|          8 |       0.8774 |               0.8774 |       0.9985 |                      284 |                       0 |                     3355.5 |              4.991 |                   84.7 |
|         14 |       0.8774 |               0.8774 |       0.9985 |                      287 |                       0 |                     3399.9 |              4.991 |                   84.7 |
|         18 |       0.8745 |               0.8774 |       0.9985 |                      287 |                       0 |                     3535.4 |              4.991 |                   84.7 |
|         25 |       0.8652 |               0.8652 |       0.9985 |                      239 |                       0 |                     3507.5 |              4.991 |                   96.3 |
|         30 |       0.8774 |               0.8774 |       0.9985 |                      275 |                       0 |                     3383.8 |              4.991 |                   95   |
|         33 |       0.8774 |               0.8774 |       0.9985 |                      276 |                       0 |                     3442   |              4.991 |                   95   |

Observations: EV energy has a strong, near-nonlinear effect (losses roughly scale with current squared). PV reduces losses up to about 4 MWp, then losses rise again as reverse flow grows; overvoltage first appears at 8 MWp. Larger battery power does not help with this fixed schedule: at 2 MW, charging at bus 18 drives the minimum voltage to about 0.76 pu and the line loading above 150% of the assumed rating. In this model, bus 8, 14 and 30 give lower daily losses than bus 18, and bus 25 gives the lowest voltage of the day (0.8652 pu); the differences between locations are modest and specific to the assumed profiles. The battery energy rating saturates beyond about 2-4 MWh because the schedule only discharges for three hours.

## 8. Validation plan

**Done by the code (`src/validate.py`, `tests/`):**
- Total load equals 3715 kW / 2300 kvar.
- Base case reproduces published loss 202.67 kW and V_min 0.9131 pu at bus 18 (tolerances 0.5 kW and 0.0005 pu).
- Voltages match pandapower's built-in `case33bw` to better than 1e-6 pu (this also caught two data-entry errors during development).
- Hourly active-power balance closes below 1e-6 MW.
- Battery power and SOC stay within limits; end-of-day SOC equals start (cyclic).

**To do before publishing:**
1. Re-run on a clean environment; confirm the README numbers match the generated CSVs.
2. Hand-check one hour (e.g., 19:00 in S0) with an independent method, such as a backward/forward sweep or a second tool.
3. Check that PV sign, EV sign and storage sign conventions produce the expected direction of import change (the tests do this for PV only).
4. State clearly in the README that profiles and sizes are assumptions; do not describe results as validated against a real utility.
5. Check that sensitivity trends make physical sense (more EV means lower voltage and higher losses).
6. Have a supervisor or peer review the assumptions, especially line ratings.

## 9. Challenges, limitations, future work

**Challenges met:** the original data set has no thermal ratings (assumed); the base network is already below 0.95 pu at peak (reported, not hidden); data-entry errors were caught only by cross-checking with a reference case.

**Limitations:** one deterministic day; synthetic profiles; single-phase equivalent; no tap changers, capacitors or inverter control (PV at unity pf); EV behaviour is an aggregate shape; battery schedule is not optimised; ratings assumed; battery degradation and economics ignored.

**Future work:** real hourly load/PV/EV data (and a full year); PV Volt-VAR/Volt-Watt control; voltage-aware or optimisation-based battery dispatch (e.g., pandapower OPF or a convex model); battery siting and sizing search; Monte-Carlo uncertainty for EV arrival and PV variability; smart/managed EV charging as an alternative to storage; comparison with network reinforcement cost.

## 10. Reproduce

```bash
pip install -r requirements.txt
python main.py
pytest -q tests
```

## References
1. Baran, M. E., Wu, F. F. (1989). Network reconfiguration in distribution systems for loss reduction and load balancing. IEEE Trans. Power Delivery, 4(2).
2. Thurner, L. et al. (2018). pandapower - an open-source Python tool for convenient modeling, analysis and optimization of electric power systems. IEEE Trans. Power Systems, 33(6).
