import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from src.bess import schedule_bess
from src.config import Study
from src.simulate import run_all
from src import validate as V


@pytest.fixture(scope="module")
def results():
    return run_all(Study())


def test_total_load():
    assert V.check_total_load()


def test_literature_base_case():
    assert V.check_against_literature()["ok"]


def test_matches_pandapower_builtin():
    assert V.check_against_pandapower_builtin()["ok"]


def test_energy_balance(results):
    assert V.check_energy_balance(results)["ok"]


def test_bess_limits(results):
    assert V.check_bess_energy(results)["ok"]


def test_bess_cyclic_and_efficiency():
    s = schedule_bess(Study())
    assert abs(s.soc[-1] - s.soc_start) < 1e-6          # cyclic steady state
    assert s.conversion_loss_mwh >= 0                   # a battery cannot create energy


def test_pv_never_negative_import_change(results):
    # Adding PV must not increase daily energy drawn from the substation
    assert results["S1_pv"].p_import_mw.sum() < results["S0_base"].p_import_mw.sum()
