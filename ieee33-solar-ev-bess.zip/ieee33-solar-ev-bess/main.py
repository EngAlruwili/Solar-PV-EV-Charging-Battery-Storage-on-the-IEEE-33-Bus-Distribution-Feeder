"""
Run the full study:  python main.py
Outputs: results/*.csv, results/kpi_summary.md, figures/*.png
"""
import sys
from pathlib import Path

import pandas as pd

from src import config as C
from src.metrics import kpi_table
from src.plots import (fig_bess, fig_kpi_bars, fig_line_loading, fig_losses, fig_min_voltage,
                       fig_profiles, fig_sensitivity, fig_substation, fig_voltage_profiles)
from src.sensitivity import sweep_bess, sweep_bess_bus, sweep_ev, sweep_pv
from src.simulate import PowerFlowError, run_all
from src.validate import run_all_checks

ROOT = Path(__file__).parent
RES, FIG = ROOT / "results", ROOT / "figures"


def main() -> int:
    RES.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True)
    study = C.Study()
    try:
        print("1/4  Running the 4 scenarios (24 power flows each) ...")
        results = run_all(study)
    except PowerFlowError as exc:
        print(f"ERROR: {exc}. Try smaller DER sizes in src/config.py."); return 1

    table = kpi_table(results)
    table.T.to_csv(RES / "kpi_summary.csv")
    (RES / "kpi_summary.md").write_text(table.T.to_markdown() if _has_tabulate() else table.T.to_string())
    for n, r in results.items():
        pd.concat({"V_pu": r.vm.add_prefix("bus_"), "loading_pct": r.line_loading.add_prefix("line_")}, axis=1) \
          .to_csv(RES / f"timeseries_{n}.csv", index_label="hour")
        pd.DataFrame({"load_MW": r.load_mw, "pv_MW": r.pv_mw, "ev_MW": r.ev_mw, "bess_MW(+charge)": r.bess_mw,
                      "bess_soc": r.bess_soc, "loss_kW": r.losses_kw, "import_MW": r.p_import_mw,
                      "import_Mvar": r.q_import_mvar}).to_csv(RES / f"powers_{n}.csv", index_label="hour")
    print(table.T.to_string())

    print("2/4  Drawing figures ...")
    for f in (fig_profiles, fig_voltage_profiles, fig_min_voltage, fig_losses,
              fig_line_loading, fig_substation, fig_bess):
        f(results, FIG)
    fig_kpi_bars(table, FIG)

    print("3/4  Sensitivity study ...")
    ev, pv, bess, bus = sweep_ev(), sweep_pv(), sweep_bess(), sweep_bess_bus()
    for name, df in (("ev", ev), ("pv", pv), ("bess_size", bess), ("bess_location", bus)):
        df.to_csv(RES / f"sensitivity_{name}.csv", index=False)
    fig_sensitivity(ev, pv, bess, bus, table.loc["S2 + PV + EV"], FIG)

    print("4/4  Validation checks ...")
    checks = run_all_checks(results)
    for k, v in checks.items():
        ok = v if isinstance(v, bool) else v["ok"]
        print(f"   [{'PASS' if ok else 'FAIL'}] {k}: {v}")
    return 0


def _has_tabulate() -> bool:
    try:
        import tabulate  # noqa: F401
        return True
    except ImportError:
        return False


if __name__ == "__main__":
    sys.exit(main())
